from django.apps import AppConfig


class MailSenderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mail_sender'
